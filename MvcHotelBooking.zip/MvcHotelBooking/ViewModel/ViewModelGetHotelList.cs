﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcHotelBooking.ViewModel
{
    public class ViewModelGetHotelList
    {
        public IEnumerable<MvcHotelBooking.tblHotelList> getHotelList { get; set; }

    }
}