﻿var batch = $("#batch option:selected").text().trim();
var option = $("#option option:selected").text().trim();
var to = $('#to').val();
var from = $('#from').val();
//alert("Domain: " + option + " From : " + from + " To: " + to);
function IsDomainEmpty() {
    if ($("#option option:selected").text().trim() == "Select Domain") {
        return 'Please select a domain.';
    }
    else { return ""; }
}


function IsDateEmpty() {
    if ($('#to').val() == "" || $('#from').val() == "") {
        return 'Date should not be empty';
    }
    else { return ""; }
}

function IsValid() {
    var DomainEmptyMessage = IsDomainEmpty();
    var DateEmptyMessage = IsDateEmpty();
    var FinalErrorMessage = "Errors:";
    if (DomainEmptyMessage != "")
        FinalErrorMessage += "\n" + DomainEmptyMessage;
    if (DateEmptyMessage != "")
        FinalErrorMessage += "\n" + DateEmptyMessage;
    if (FinalErrorMessage != "Errors:") {
        alert(FinalErrorMessage);
        return false;
    }
    else {
        return true;
    }
}