﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace MvcHotelBooking.Controllers
{
    public class HomeController : Controller
    {
        myDbEntities db = new myDbEntities();
        // GET: Home
        public ActionResult Index()
        {
            
            ViewBag.CityList = db.tblCityMasters.ToList();
            return View();
        }


        public ActionResult Show(int id)
        {
            var imageData = from names in db.tblHotelLists
                            where names.Id == id
                            select names; // ...get bytes from database...
            dynamic data = "";
            foreach(tblHotelList m in imageData)
            {
                data = m.HotelImage;
            }
        return File(data, "image/jpg");
        }


        [HttpPost]
        public ActionResult SearchData(string cityOption)
        {

            try
            {

                var model = new MvcHotelBooking.ViewModel.ViewModelGetHotelList();
                model.getHotelList = db.tblHotelLists.Where(x => x.City == cityOption).ToList();
                
                    return View("SearchData", model);
                

            }
            catch (Exception Ex)
            {
                var frame = new StackTrace(Ex, true).GetFrame(0); // where the error originated
                var lineNumber = frame.GetFileLineNumber(); //to get error line number
                ViewBag.ex = Ex.Message + " <br>Action Name:" + Ex.TargetSite.Name + " <br>Controller: " + Ex.TargetSite.DeclaringType.FullName + " <br>Line Number: " + lineNumber;
                return View("Error");
            }
        }
        public ActionResult GetCityList(string selectedCity)
        {
            var query =                from names in db.tblCityMasters
                                       where names.NameOfCity == selectedCity
                                       select names;
            var states="";
            foreach(tblCityMaster item in query)
            {
                states = item.State;
            }
                JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
                string result = javaScriptSerializer.Serialize(states);
                return Json(result, JsonRequestBehavior.AllowGet);
            


        }


    }
}